-- phpMyAdmin SQL Dump
-- version  4.0.4.1-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 23, 2010 at 06:23 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `carttemp`
--

CREATE TABLE IF NOT EXISTS `carttemp` (
  `hidden` int(10) NOT NULL AUTO_INCREMENT,
  `sess` char(50) NOT NULL,
  `prodnum` char(5) NOT NULL,
  `quan` int(3) NOT NULL,
  PRIMARY KEY (`hidden`),
  KEY `sess` (`sess`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `carttemp`
--


-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `custnum` int(6) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(15) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `add1` varchar(50) NOT NULL,
  `add2` varchar(50) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `state` char(2) NOT NULL,
  `zip` char(5) NOT NULL,
  `phone` char(12) NOT NULL,
  `fax` char(12) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`custnum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customers`
--


-- --------------------------------------------------------

--
-- Table structure for table `orderdet`
--

CREATE TABLE IF NOT EXISTS `orderdet` (
  `ordernum` int(6) NOT NULL,
  `qty` int(3) NOT NULL,
  `prodnum` char(5) NOT NULL,
  KEY `ordernum` (`ordernum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdet`
--


-- --------------------------------------------------------

--
-- Table structure for table `ordermain`
--

CREATE TABLE IF NOT EXISTS `ordermain` (
  `ordernum` int(6) NOT NULL AUTO_INCREMENT,
  `orderdate` date NOT NULL,
  `custnum` int(6) NOT NULL,
  `subtotal` decimal(7,2) NOT NULL,
  `shipping` decimal(6,2) DEFAULT NULL,
  `tax` decimal(6,2) DEFAULT NULL,
  `total` decimal(7,2) NOT NULL,
  `shipfirst` varchar(15) NOT NULL,
  `shiplast` varchar(50) NOT NULL,
  `shipcompany` varchar(50) DEFAULT NULL,
  `shipadd1` varchar(50) NOT NULL,
  `shipadd2` varchar(50) DEFAULT NULL,
  `shipcity` varchar(50) NOT NULL,
  `shipstate` char(2) NOT NULL,
  `shipzip` char(5) NOT NULL,
  `shipphone` char(12) NOT NULL,
  `shipemail` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ordernum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ordermain`
--


-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `prodnum` char(5) NOT NULL,
  `img` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `proddesc` text NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `dateadded` date NOT NULL,
  PRIMARY KEY (`prodnum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prodnum`, `img`, `name`, `proddesc`, `price`, `dateadded`) VALUES
('00001', 'images/soni1.jpg', 'high red heels', 'These heels will show off your CBA connection.\r\nOur heels are high quality and super fine.', '1117.95', '2003-08-01'),
('00002', 'images/soni2.jpg', 'red pencil heels', 'Let the world know you are a proud supporter of the\r\nCBA Web site with this colorful heels.', '1115.95', '2003-08-01'),
('00003', 'images/soni3.jpg', 'the dark queen', 'With the CBA logo looking back at you over your\r\stylish walk, you''re sure to have a great\r\nstart to your day. Our heels are comfortabler\r\nsafe.', '800.95', '2003-08-01'),
('00004', 'images/soni4.jpg', 'pink princess', 'We have a complete selection of colors and sizes for you\r\nto choose from. This footwear is sleek, stylish, and\r\nwon''t hinder your crime-fighting or evil scheming abilities.\r\nWe also offer your choice in monogrammed letter applique.', '1199.95', '2003-08-01'),
('00005', 'images/soni5.jpg', 'trendy suit', 'This suit will get you out of the tightest\r\nplaces. Specially designed for comfort and fashion.', '1139.95', '2003-08-01'),
('00006', 'images/soni13.jpg', 'the flawless dress', 'this will charm your personality\r\n throughout the city.', '1199.95', '2003-08-01');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
